package cl.duoc.facturacionMS.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import cl.duoc.facturacionMS.DTO.RepuestoDTO;

@FeignClient(name = "msRepuestos", url = "http://localhost:8082")
public interface RepuestoCLient {

    @GetMapping("/api/v1/repuestos/dto/{id}")
    RepuestoDTO obtenerRepuestoPorId(@PathVariable("id") Integer id);
}
