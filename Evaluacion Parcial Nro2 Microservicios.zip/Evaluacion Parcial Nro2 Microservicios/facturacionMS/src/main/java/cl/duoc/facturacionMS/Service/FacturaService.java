package cl.duoc.facturacionMS.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.duoc.facturacionMS.Client.ClienteClient;
import cl.duoc.facturacionMS.Client.MecanicoClient;
import cl.duoc.facturacionMS.Client.OrdenesTrabajoClient;
import cl.duoc.facturacionMS.Client.RepuestoCLient;
import cl.duoc.facturacionMS.Client.VehiculoClient;
import cl.duoc.facturacionMS.DTO.ClienteDTO;
import cl.duoc.facturacionMS.DTO.FacturaDetalleDTO;
import cl.duoc.facturacionMS.DTO.MecanicoDTO;
import cl.duoc.facturacionMS.DTO.OrdenTrabajoDTO;
import cl.duoc.facturacionMS.DTO.PagoDTO;
import cl.duoc.facturacionMS.DTO.RepuestoDTO;
import cl.duoc.facturacionMS.DTO.VehiculoDTO;
import cl.duoc.facturacionMS.Model.Factura;
import cl.duoc.facturacionMS.Model.Pago;
import cl.duoc.facturacionMS.Repository.FacturaRepository;
import cl.duoc.facturacionMS.Repository.PagoRepository;

@Service
public class FacturaService {

    @Autowired
    private FacturaRepository facturaRepository;

    @Autowired
    private PagoRepository PagoRepository;

    @Autowired
    private OrdenesTrabajoClient ordenClient;

    @Autowired
    private RepuestoCLient repuestoClient;

    @Autowired
    private VehiculoClient vehiculoClient;
    
    @Autowired
    private MecanicoClient mecanicoClient;

    @Autowired
    private ClienteClient clienteClient;

    //Gestión de facturas

    public List<Factura> listarFacturas() {
        return facturaRepository.findAll();
    }

    public Factura buscarPorId(Integer id) {
        return facturaRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Factura no encontrada"));
    }

    public Factura guardarFactura(Factura factura) {
    
        VehiculoDTO vehiculoDTO = vehiculoClient.obtenerVehiculoPorId(factura.getVehiculoId());
        if (vehiculoDTO == null) {
            throw new RuntimeException("Vehículo no encontrado");
        }

        MecanicoDTO mecanicoDTO = mecanicoClient.obtenerMecanicoPorId(factura.getMecanicoId());
        if (mecanicoDTO == null) {
            throw new RuntimeException("Mecánico no encontrado");
        }

        ClienteDTO clienteDTO = clienteClient.obtenerClientePorId(factura.getClienteId());
        if (clienteDTO == null) {
            throw new RuntimeException("Cliente no encontrado");
        }

        RepuestoDTO repuestoDTO = repuestoClient.obtenerRepuestoPorId(factura.getId());
        if (repuestoDTO == null) {
            throw new RuntimeException("Repuesto no encontrado");
        }
        
        return facturaRepository.save(factura);
    }

    @Transactional(readOnly = true)
    public FacturaDetalleDTO obtenerDetalle(Integer facturaId) {
        Factura factura = buscarPorId(facturaId);

        //Obtener orden de trabajo asociada
        OrdenTrabajoDTO orden = ordenClient.obtenerOrden(factura.getOrdenId());
        if  (orden == null) {
            throw new RuntimeException("No se pudo recuperar la orden asociada");
        }

        // Obtener pagos en esta factura
        List<Pago> pagos = PagoRepository.findByFacturaId(facturaId);
        List<PagoDTO> pagosDTO = pagos.stream().map(p -> {
            PagoDTO dto = new PagoDTO();
            
            dto.setId(p.getId());
            dto.setMonto(p.getMonto());
            dto.setFechaPago(p.getFechaPago());
            dto.setMetodoPago(p.getMetodoPago());
            dto.setReferencia(p.getReferencia());
            return dto;
        }).collect(Collectors.toList());
        
        FacturaDetalleDTO detalle = new FacturaDetalleDTO();

        detalle.setId(factura.getId());
        detalle.setNumeroBoleta(factura.getNumeroBoleta());
        detalle.setFechaEmision(factura.getFechaEmision());
        detalle.setSubtotalRepuestos(factura.getSubtotalRepuestos());
        detalle.setIva(factura.getIva());
        detalle.setTotalFinal(factura.getTotalFinal());
        detalle.setOrdenTrabajo(orden);
        detalle.setPagos(pagosDTO);

        return detalle;
    }

    //Gestión de pagos

    @Transactional
    public Pago registrarPago(Integer facturaId, Pago pago) {
        Factura factura = buscarPorId(facturaId);

        //Validar que el monto del pago no supere el total

        BigDecimal totalPagado = PagoRepository.findByFacturaId(facturaId).stream()
            .map(Pago::getMonto)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        if (totalPagado.add(pago.getMonto()).compareTo(factura.getTotalFinal()) > 0) {
            throw new RuntimeException("El pago super el total de la factura");
        }

        pago.setFactura(factura);
        pago.setFechaPago(factura.getFechaEmision());
        return PagoRepository.save(pago);
    }

    public List<Pago> listarPagos(Integer facturaId){ 
        return PagoRepository.findByFacturaId(facturaId);
    }
}
