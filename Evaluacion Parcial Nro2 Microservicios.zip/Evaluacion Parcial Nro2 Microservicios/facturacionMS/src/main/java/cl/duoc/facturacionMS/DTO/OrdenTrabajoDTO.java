package cl.duoc.facturacionMS.DTO;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrdenTrabajoDTO {

    private String fecha;
    private String descripcion;
    private VehiculoDTO vehiculoId;
    private MecanicoDTO mecanicoId;
    private ClienteDTO clienteId;
}
