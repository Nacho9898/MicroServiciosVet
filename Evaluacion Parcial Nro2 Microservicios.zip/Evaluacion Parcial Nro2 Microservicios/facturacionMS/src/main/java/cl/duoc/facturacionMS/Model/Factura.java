package cl.duoc.facturacionMS.Model;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.*;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "facturas")
public class Factura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "numero_boleta", nullable = false, unique = true)
    private Long numeroBoleta;

    @Column(name = "fecha_emision", nullable = false)
    private Date fechaEmision;

    @Column(name = "orden_id", nullable = false, unique = true)
    private Integer ordenId;

    @Column(name = "subtotal_repuestos", precision = 12, scale = 2)
    private BigDecimal subtotalRepuestos;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal iva;

    @Column(nullable = false)
    private Integer mecanicoId;

    @Column(nullable = false)
    private Integer vehiculoId;

    @Column(nullable = false)
    private Integer clienteId;

    @Column(name = "total_final", nullable = false, precision = 12, scale = 2)
    private BigDecimal totalFinal;
}