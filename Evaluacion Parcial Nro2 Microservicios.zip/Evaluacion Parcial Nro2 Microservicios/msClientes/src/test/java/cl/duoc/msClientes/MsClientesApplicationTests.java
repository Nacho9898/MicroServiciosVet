package cl.duoc.msClientes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsClientesApplicationTests {

	@Test
	void contextLoads() {
	}

}
