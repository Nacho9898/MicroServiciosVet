package cl.duoc.notificacionesMS.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NotificacionDetalleDTO {

    private Integer id;
    private String mensaje;
    private String fecha;

    // Datos del destinatario obtenidos de otros MS
    private ClienteDTO cliente;
    private MecanicoDTO mecanico;
}