package cl.duoc.notificacionesMS.service;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cl.duoc.notificacionesMS.client.ClienteClient;
import cl.duoc.notificacionesMS.client.MecanicoClient;
import cl.duoc.notificacionesMS.dto.ClienteDTO;
import cl.duoc.notificacionesMS.dto.MecanicoDTO;
import cl.duoc.notificacionesMS.dto.NotificacionDetalleDTO;
import cl.duoc.notificacionesMS.model.Notificacion;
import cl.duoc.notificacionesMS.repository.NotificacionRepository;

@Service
public class NotificacionService {

    @Autowired
    private NotificacionRepository repository;

    @Autowired
    private ClienteClient clienteClient;

    @Autowired
    private MecanicoClient mecanicoClient;


    // CRUD


    public Notificacion crear(Notificacion notificacion) {
        notificacion.setFechaCreacion(LocalDateTime.now());
        notificacion.setEstado("PENDIENTE");
        return repository.save(notificacion);
    }

    public List<Notificacion> listar() {
        return repository.findAll();
    }

    public Notificacion buscarPorId(Integer id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Notificación no encontrada"));
    }

    // Simular envío (cambiar estado a ENVIADA)
    public Notificacion enviar(Integer id) {
        Notificacion notif = buscarPorId(id);
        // Aquí iría lógica real de envío (email, SMS)
        notif.setEstado("ENVIADA");
        notif.setFechaEnvio(LocalDateTime.now());
        return repository.save(notif);
    }


    //Detalle de datos


    public NotificacionDetalleDTO obtenerDetalle(Integer id) {
        Notificacion notif = buscarPorId(id);

        MecanicoDTO mecanico = mecanicoClient.obtenerMecanico(notif.getMecanicoId());
        ClienteDTO cliente = clienteClient.obtenerCliente(notif.getClienteId());

        NotificacionDetalleDTO dto = new NotificacionDetalleDTO();

        dto.setId(notif.getId());
        dto.setMensaje(notif.getMensaje());
        dto.setFecha(notif.getFechaCreacion().toString());
        dto.setCliente(cliente);
        dto.setMecanico(mecanico);

        return dto;
    }
}