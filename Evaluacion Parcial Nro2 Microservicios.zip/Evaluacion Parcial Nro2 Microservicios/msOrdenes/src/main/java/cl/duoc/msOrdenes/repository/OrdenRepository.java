package cl.duoc.msOrdenes.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import cl.duoc.msOrdenes.model.Orden;

@Repository
public interface OrdenRepository extends JpaRepository<Orden, Integer> {

    Optional<Orden> findByClienteId(Integer clienteId);

    Optional<Orden> findByVehiculoId(Integer vehiculoId);

    Optional<Orden> findByMecanicoId(Integer mecanicoId);
}
