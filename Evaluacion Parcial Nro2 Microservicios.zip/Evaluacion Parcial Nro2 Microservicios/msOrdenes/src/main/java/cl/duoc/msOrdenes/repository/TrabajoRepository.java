package cl.duoc.msOrdenes.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import cl.duoc.msOrdenes.model.Trabajo;

@Repository
public interface TrabajoRepository extends JpaRepository<Trabajo, Integer> {

}
