package cl.duoc.msOrdenes.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cl.duoc.msOrdenes.client.ClienteClient;
import cl.duoc.msOrdenes.client.MecanicoClient;
import cl.duoc.msOrdenes.client.VehiculoClient;
import cl.duoc.msOrdenes.dto.ClienteDTO;
import cl.duoc.msOrdenes.dto.MecanicoDTO;
import cl.duoc.msOrdenes.dto.OrdenDTO;
import cl.duoc.msOrdenes.dto.VehiculoDTO;
import cl.duoc.msOrdenes.model.Orden;
import cl.duoc.msOrdenes.model.Trabajo;
import cl.duoc.msOrdenes.repository.OrdenRepository;
import cl.duoc.msOrdenes.repository.TrabajoRepository;

@Service
public class OrdenService {

    @Autowired
    private OrdenRepository repoOrden;

    @Autowired
    private TrabajoRepository repoTrabajo;

    @Autowired
    private VehiculoClient vehiculoClient;

    @Autowired
    private MecanicoClient mecanicoClient;

    @Autowired
    private ClienteClient clienteClient;

    public List<Orden> listarOrdenes() {
        return repoOrden.findAll();
    }

    public Orden buscarOrdenPorId(Integer id) {
        return repoOrden.findById(id).orElseThrow(() -> new RuntimeException("Orden no encontrada"));
    }

    public Trabajo buscarTrabajoPorId(Integer id) {
        return repoTrabajo.findById(id).orElseThrow(() -> new RuntimeException("Trabajo no encontrado"));
    }

    public Orden buscarOrdenesPorClienteId(Integer clienteId){
        return repoOrden.findByClienteId(clienteId).orElseThrow(() -> new RuntimeException("Cliente no encontrado"));
    }

    public Orden buscarOrdenesPorVehiculoId(Integer vehiculoId){
        return repoOrden.findByVehiculoId(vehiculoId).orElseThrow(() -> new RuntimeException("Vehiculo no encontrado"));
    }

    public Orden buscarTrabajosPorMecanicoId(Integer mecanicoId){
        return repoOrden.findByMecanicoId(mecanicoId).orElseThrow(() -> new RuntimeException("Mecanico no encontrado"));
    }

    public Orden crearOrden(Orden orden) {
        return repoOrden.save(orden);
    }

    public Orden guardarOrden(Orden orden) {
    
        VehiculoDTO vehiculoDTO = vehiculoClient.obtenerVehiculoPorId(orden.getVehiculoId());
        if (vehiculoDTO == null) {
            throw new RuntimeException("Vehículo no encontrado");
        }

        MecanicoDTO mecanicoDTO = mecanicoClient.obtenerMecanicoPorId(orden.getMecanicoId());
        if (mecanicoDTO == null) {
            throw new RuntimeException("Mecánico no encontrado");
        }

        ClienteDTO clienteDTO = clienteClient.obtenerClientePorId(orden.getClienteId());
        if (clienteDTO == null) {
            throw new RuntimeException("Cliente no encontrado");
        }

        return repoOrden.save(orden);
    }

    public Orden actualizarOrden(Integer id, Orden ordenActualizada) {
        Orden ordenExistente = repoOrden.findById(id).orElseThrow(() -> new RuntimeException("Orden no encontrada"));

        ordenExistente.setObservaciones(ordenActualizada.getObservaciones());
        ordenExistente.setEstado(ordenActualizada.getEstado());
        ordenExistente.setFechaOrden(ordenActualizada.getFechaOrden());

        return repoOrden.save(ordenExistente);
    }

    public void eliminarOrden(Integer id) {
        Orden ordenExistente = repoOrden.findById(id).orElseThrow(() -> new RuntimeException("Orden no encontrada"));
        repoOrden.delete(ordenExistente);
    }

    public OrdenDTO mostrarDetalleOrden(Integer id) {
        Orden orden = repoOrden.findById(id).orElseThrow(() -> new RuntimeException("Orden no encontrada"));

        VehiculoDTO vehiculo = vehiculoClient.obtenerVehiculoPorId(orden.getVehiculoId());
        MecanicoDTO mecanico = mecanicoClient.obtenerMecanicoPorId(orden.getMecanicoId());
        ClienteDTO cliente = clienteClient.obtenerClientePorId(orden.getClienteId());

        OrdenDTO dto = new OrdenDTO();

        dto.setVehiculo(vehiculo);
        dto.setMecanico(mecanico);
        dto.setCliente(cliente);
        dto.setFecha(orden.getFechaOrden().toString());
        dto.setDescripcion(orden.getObservaciones());

        return dto;
    }
}
