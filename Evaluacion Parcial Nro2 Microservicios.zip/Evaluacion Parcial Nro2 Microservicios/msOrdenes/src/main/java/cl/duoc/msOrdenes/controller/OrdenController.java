package cl.duoc.msOrdenes.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import cl.duoc.msOrdenes.dto.OrdenDTO;
import cl.duoc.msOrdenes.model.Orden;
import cl.duoc.msOrdenes.model.Trabajo;
import cl.duoc.msOrdenes.service.OrdenService;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;

@RestController
@RequestMapping("/api/v1/ordenes")
public class OrdenController {

    @Autowired
    private OrdenService service;

    @GetMapping
    public ResponseEntity<List<Orden>> listarOrdenes(){

        List<Orden> listaOrdenes = service.listarOrdenes();
        if (listaOrdenes.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(listaOrdenes);
        }
    }

    @GetMapping("/orden/{id}")
    public ResponseEntity<Orden> obtenerOrdenPorId(@PathVariable Integer id){
        try {
            Orden orden = service.buscarOrdenPorId(id);
            return ResponseEntity.ok(orden);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/dto/{id}")
    public ResponseEntity<OrdenDTO> obtenerOrdenDTOPorId(@PathVariable Integer id){
        try {
            OrdenDTO ordenDTO = service.mostrarDetalleOrden(id);
            return ResponseEntity.ok(ordenDTO);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping("/trabajo/{id}")
    public ResponseEntity<Trabajo> obtenerTrabajoPorId(@PathVariable Integer id){
        try {
            Trabajo trabajo = service.buscarTrabajoPorId(id);
            return ResponseEntity.ok(trabajo);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping("/cliente/{id}")
    public ResponseEntity<Orden> obtenerOrdenesPorClienteId(@PathVariable Integer id){
        try {
            Orden orden = service.buscarOrdenesPorClienteId(id);
            return ResponseEntity.ok(orden);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping("/vehiculo/{id}")
    public ResponseEntity<Orden> obtenerOrdenPorVehiculoId(@PathVariable Integer id){
        try {
            Orden orden = service.buscarOrdenesPorVehiculoId(id);
            return ResponseEntity.ok(orden);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Orden> guardarOrden(@RequestBody Orden orden){
        Orden nuevaOrden = service.guardarOrden(orden);
        return ResponseEntity.ok(nuevaOrden);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Orden> actualizarOrden(@PathVariable Integer id, @RequestBody Orden orden){
        try {
            Orden ordenActualizada = service.actualizarOrden(id, orden);
            return ResponseEntity.ok(ordenActualizada);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarOrden(@PathVariable Integer id){
        try {
            service.eliminarOrden(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/detalle/{id}")
    public ResponseEntity<OrdenDTO> mostrarDetalleOrden(@PathVariable Integer id) {
        try {
            OrdenDTO ordenDTO = service.mostrarDetalleOrden(id);
            return ResponseEntity.ok(ordenDTO);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
