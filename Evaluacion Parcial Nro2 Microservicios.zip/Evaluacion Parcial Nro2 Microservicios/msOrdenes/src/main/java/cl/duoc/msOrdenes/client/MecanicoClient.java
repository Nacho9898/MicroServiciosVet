package cl.duoc.msOrdenes.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import cl.duoc.msOrdenes.dto.MecanicoDTO;

@FeignClient(name = "msMecanicos", url = "http://localhost:8084")
public interface MecanicoClient {

    @GetMapping("/api/v1/mecanicos/dto/{id}")
    MecanicoDTO obtenerMecanicoPorId(@PathVariable("id") Integer id);

}
