package cl.duoc.reportesMS.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FacturaDetalleDTO {

    private Integer id;
    private Long numeroBoleta;
    private Date fechaEmision;
    private BigDecimal subtotalManoObra;
    private BigDecimal subtotalRepuestos;
    private BigDecimal iva;
    private BigDecimal totalFinal;

    // Datos externos desde órdenes MS
    private OrdenDTO ordenTrabajo;

    // Pagos realizados a esta factura
    private List<PagoDTO> pagos;
}