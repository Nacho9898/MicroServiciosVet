package cl.duoc.reportesMS.client;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import cl.duoc.reportesMS.dto.OrdenDTO;

@FeignClient(name = "msOrdenes", url = "http://localhost:8083")
public interface OrdenesTrabajoClient {

    @GetMapping("/api/v1/ordenes/dto/{id}")
    List<OrdenDTO> obtenerOrden(@PathVariable("id") Integer id);
}