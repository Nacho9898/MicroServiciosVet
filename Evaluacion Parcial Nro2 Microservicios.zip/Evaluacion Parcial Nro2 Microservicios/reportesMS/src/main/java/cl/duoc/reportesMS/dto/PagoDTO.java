package cl.duoc.reportesMS.dto;

import java.math.BigDecimal;
import java.util.Date;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class PagoDTO {

    private Integer id;
    private BigDecimal monto;
    private Date fechaPago;
    private String metodoPago;
    private String referencia;
}
