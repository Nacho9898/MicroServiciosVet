package cl.duoc.reportesMS.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class CitaDetalleDTO {

    private Integer id;
    private String fecha;
    private VehiculoDTO vehiculo;
    private ClienteDTO cliente;
}