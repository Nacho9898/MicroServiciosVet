package cl.duoc.reportesMS.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import cl.duoc.reportesMS.dto.VehiculoDTO;

@FeignClient(name = "msVehiculos", url = "http://localhost:8080")
public interface VehiculoClient {

    @GetMapping("/api/v1/vehiculos/dto/{id}")
    VehiculoDTO obtenerVehiculoPorId(@PathVariable("id") Integer id);




}