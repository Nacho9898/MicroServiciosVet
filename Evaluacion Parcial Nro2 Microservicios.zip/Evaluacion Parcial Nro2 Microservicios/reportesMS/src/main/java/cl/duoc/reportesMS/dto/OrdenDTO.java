package cl.duoc.reportesMS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrdenDTO {

    private String fecha;
    private String descripcion;
    private VehiculoDTO vehiculo;
    private MecanicoDTO mecanico;
    private ClienteDTO cliente;

}