package cl.duoc.reportesMS.client;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import cl.duoc.reportesMS.dto.CitaDetalleDTO;

@FeignClient(name = "msCitas", url = "http://localhost:8085")
public interface CitaClient {

    @GetMapping("/api/v1/citas/dto/{id}")
    List<CitaDetalleDTO> obtenerCita(@PathVariable("id") Integer id);
}