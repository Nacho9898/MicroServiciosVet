package cl.duoc.proveedoresMS.client;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import cl.duoc.proveedoresMS.dto.RepuestoDTO;

@FeignClient(name = "msRepuestos", url = "http://localhost:8082")
public interface RepuestoClient {

    @GetMapping("/api/v1/repuestos/dto/{id}")
    List<RepuestoDTO> obtenerRepuestos(@PathVariable("id") Integer idRepuesto);
}